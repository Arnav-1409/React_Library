import React, { Component } from 'react';
import './App.css';
import CATEGORY from './container/CATEGORY';
import DISPLAY from './container/DISPLAY';

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      book: [],
      category: [],
      newData: []
    }
    this.fetchData = this.fetchData.bind(this);

  }

  componentDidMount() {
    this.fetchData();
  }
  fetchData() {
    fetch("http://www.json-generator.com/api/json/get/bUmCwZpDtu?indent=2", {
      method: "GET",
      dataType: "JSON",
    })
      .then((resp) => {
        return resp.json()
      })
      .then((resp) => {

        this.setState({ book: resp.books })
        this.setState({ category: resp.Category })
        console.log('fetched', this.state)

      })
      .catch((error) => {
        console.log(error, "error!")
      })
  }
  handleclick = (value, bookDetail) => {
    let x = value.target.id;
    let newArray = Object.values(bookDetail[x])
    this.setState({
      ...this.state,
      newData: newArray
    })
  }
  render() {
    let category = this.state.category;
    return (
      <div className="App">
        <CATEGORY category={category}
          handleclick={this.handleclick}
          bookDetail={this.state.book}
        />
        <DISPLAY
          newData={this.state.newData} />
      </div>
    );
  }
}

export default App;