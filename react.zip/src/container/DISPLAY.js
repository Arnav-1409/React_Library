import React, { Component } from 'react';
import './app.css';
function DISPLAY(props) {
    let details = props.newData;
    return (
        <div className='parent-container'>
            <div className='right-container'>
                <div className="column" id="data">
                    <h2>Name</h2>
                </div>
                <div className="column" id="data">
                    <h2>Description</h2>
                </div>
                <div className="column" id="data">
                    <h2>Category</h2>
              </div>
                {details.map(details => <div className='row2' key={details.name}>
                        <div className='column'>{details.name}</div>
                        <div className='column'>{details.description}</div>
                        <div className='column'>{details.category} </div>
                </div>
                )}
            </div>
        </div>
    )
}
export default DISPLAY;