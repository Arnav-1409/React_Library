import React, { Component } from 'react';

export default class CATEGORY extends Component {
    render() {
        return (
            <div className="left-container" id="category">
            <h2>BOOKS CATEGORY</h2>
                <ul className='List' id="List" onClick={(e) => this.props.handleclick(e, this.props.bookDetail)}>
                    {this.props.category ? Object.keys(this.props.category).map((key) => {
                        return <li key={key} id={key}>{this.props.category[key]}
                        </li>
                    }) : ''}
                </ul>
            </div>
        )
    }
}